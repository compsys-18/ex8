#include <mips.h>

int main()
{
    /* Exercise 5-1 */
    /*test_gate();*/

    /* Exercise 5-2 */
    /*test_full_adder();*/

    /* Exercise 5-3 */
    /*test_rca(100, 200);
    test_rca(1<<30, (1<<30)-1);
    test_rca(1<<30, 1<<30);
    test_rca(1<<31, 1<<31);*/

    /* Exercise 6-1 */
    /*test_mux();
    test_alu();
    test_alu32(100, 200);
    test_alu32(100, 100);
    test_overflow();*/

    /* Exercise 7-1 */
    /*test_register_file();*/

    /* Exercise 7-2 */
    /*test_inst_memory();
    test_data_memory();*/

    /* Exercise 8-1 */
    test_mips();

    return 0;
}
